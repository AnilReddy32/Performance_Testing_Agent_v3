/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 173.0, "minX": 0.0, "maxY": 1149.0, "series": [{"data": [[0.0, 173.0], [0.1, 173.0], [0.2, 173.0], [0.3, 173.0], [0.4, 173.0], [0.5, 173.0], [0.6, 173.0], [0.7, 173.0], [0.8, 173.0], [0.9, 173.0], [1.0, 173.0], [1.1, 173.0], [1.2, 173.0], [1.3, 173.0], [1.4, 173.0], [1.5, 173.0], [1.6, 173.0], [1.7, 177.0], [1.8, 177.0], [1.9, 177.0], [2.0, 177.0], [2.1, 177.0], [2.2, 177.0], [2.3, 177.0], [2.4, 177.0], [2.5, 177.0], [2.6, 177.0], [2.7, 177.0], [2.8, 177.0], [2.9, 177.0], [3.0, 177.0], [3.1, 177.0], [3.2, 177.0], [3.3, 189.0], [3.4, 189.0], [3.5, 189.0], [3.6, 189.0], [3.7, 189.0], [3.8, 189.0], [3.9, 189.0], [4.0, 189.0], [4.1, 189.0], [4.2, 189.0], [4.3, 189.0], [4.4, 189.0], [4.5, 189.0], [4.6, 189.0], [4.7, 189.0], [4.8, 189.0], [4.9, 189.0], [5.0, 198.0], [5.1, 198.0], [5.2, 198.0], [5.3, 198.0], [5.4, 198.0], [5.5, 198.0], [5.6, 198.0], [5.7, 198.0], [5.8, 198.0], [5.9, 198.0], [6.0, 198.0], [6.1, 198.0], [6.2, 198.0], [6.3, 198.0], [6.4, 198.0], [6.5, 198.0], [6.6, 263.0], [6.7, 263.0], [6.8, 263.0], [6.9, 263.0], [7.0, 263.0], [7.1, 263.0], [7.2, 263.0], [7.3, 263.0], [7.4, 263.0], [7.5, 263.0], [7.6, 263.0], [7.7, 263.0], [7.8, 263.0], [7.9, 263.0], [8.0, 263.0], [8.1, 263.0], [8.2, 285.0], [8.3, 285.0], [8.4, 285.0], [8.5, 285.0], [8.6, 285.0], [8.7, 285.0], [8.8, 285.0], [8.9, 285.0], [9.0, 285.0], [9.1, 285.0], [9.2, 285.0], [9.3, 285.0], [9.4, 285.0], [9.5, 285.0], [9.6, 285.0], [9.7, 285.0], [9.8, 285.0], [9.9, 290.0], [10.0, 290.0], [10.1, 290.0], [10.2, 290.0], [10.3, 290.0], [10.4, 290.0], [10.5, 290.0], [10.6, 290.0], [10.7, 290.0], [10.8, 290.0], [10.9, 290.0], [11.0, 290.0], [11.1, 290.0], [11.2, 290.0], [11.3, 290.0], [11.4, 290.0], [11.5, 296.0], [11.6, 296.0], [11.7, 296.0], [11.8, 296.0], [11.9, 296.0], [12.0, 296.0], [12.1, 296.0], [12.2, 296.0], [12.3, 296.0], [12.4, 296.0], [12.5, 296.0], [12.6, 296.0], [12.7, 296.0], [12.8, 296.0], [12.9, 296.0], [13.0, 296.0], [13.1, 296.0], [13.2, 297.0], [13.3, 297.0], [13.4, 297.0], [13.5, 297.0], [13.6, 297.0], [13.7, 297.0], [13.8, 297.0], [13.9, 297.0], [14.0, 297.0], [14.1, 297.0], [14.2, 297.0], [14.3, 297.0], [14.4, 297.0], [14.5, 297.0], [14.6, 297.0], [14.7, 297.0], [14.8, 297.0], [14.9, 297.0], [15.0, 297.0], [15.1, 297.0], [15.2, 297.0], [15.3, 297.0], [15.4, 297.0], [15.5, 297.0], [15.6, 297.0], [15.7, 297.0], [15.8, 297.0], [15.9, 297.0], [16.0, 297.0], [16.1, 297.0], [16.2, 297.0], [16.3, 297.0], [16.4, 298.0], [16.5, 298.0], [16.6, 298.0], [16.7, 298.0], [16.8, 298.0], [16.9, 298.0], [17.0, 298.0], [17.1, 298.0], [17.2, 298.0], [17.3, 298.0], [17.4, 298.0], [17.5, 298.0], [17.6, 298.0], [17.7, 298.0], [17.8, 298.0], [17.9, 298.0], [18.0, 298.0], [18.1, 299.0], [18.2, 299.0], [18.3, 299.0], [18.4, 299.0], [18.5, 299.0], [18.6, 299.0], [18.7, 299.0], [18.8, 299.0], [18.9, 299.0], [19.0, 299.0], [19.1, 299.0], [19.2, 299.0], [19.3, 299.0], [19.4, 299.0], [19.5, 299.0], [19.6, 299.0], [19.7, 301.0], [19.8, 301.0], [19.9, 301.0], [20.0, 301.0], [20.1, 301.0], [20.2, 301.0], [20.3, 301.0], [20.4, 301.0], [20.5, 301.0], [20.6, 301.0], [20.7, 301.0], [20.8, 301.0], [20.9, 301.0], [21.0, 301.0], [21.1, 301.0], [21.2, 301.0], [21.3, 301.0], [21.4, 302.0], [21.5, 302.0], [21.6, 302.0], [21.7, 302.0], [21.8, 302.0], [21.9, 302.0], [22.0, 302.0], [22.1, 302.0], [22.2, 302.0], [22.3, 302.0], [22.4, 302.0], [22.5, 302.0], [22.6, 302.0], [22.7, 302.0], [22.8, 302.0], [22.9, 302.0], [23.0, 305.0], [23.1, 305.0], [23.2, 305.0], [23.3, 305.0], [23.4, 305.0], [23.5, 305.0], [23.6, 305.0], [23.7, 305.0], [23.8, 305.0], [23.9, 305.0], [24.0, 305.0], [24.1, 305.0], [24.2, 305.0], [24.3, 305.0], [24.4, 305.0], [24.5, 305.0], [24.6, 306.0], [24.7, 306.0], [24.8, 306.0], [24.9, 306.0], [25.0, 306.0], [25.1, 306.0], [25.2, 306.0], [25.3, 306.0], [25.4, 306.0], [25.5, 306.0], [25.6, 306.0], [25.7, 306.0], [25.8, 306.0], [25.9, 306.0], [26.0, 306.0], [26.1, 306.0], [26.2, 306.0], [26.3, 308.0], [26.4, 308.0], [26.5, 308.0], [26.6, 308.0], [26.7, 308.0], [26.8, 308.0], [26.9, 308.0], [27.0, 308.0], [27.1, 308.0], [27.2, 308.0], [27.3, 308.0], [27.4, 308.0], [27.5, 308.0], [27.6, 308.0], [27.7, 308.0], [27.8, 308.0], [27.9, 309.0], [28.0, 309.0], [28.1, 309.0], [28.2, 309.0], [28.3, 309.0], [28.4, 309.0], [28.5, 309.0], [28.6, 309.0], [28.7, 309.0], [28.8, 309.0], [28.9, 309.0], [29.0, 309.0], [29.1, 309.0], [29.2, 309.0], [29.3, 309.0], [29.4, 309.0], [29.5, 309.0], [29.6, 314.0], [29.7, 314.0], [29.8, 314.0], [29.9, 314.0], [30.0, 314.0], [30.1, 314.0], [30.2, 314.0], [30.3, 314.0], [30.4, 314.0], [30.5, 314.0], [30.6, 314.0], [30.7, 314.0], [30.8, 314.0], [30.9, 314.0], [31.0, 314.0], [31.1, 314.0], [31.2, 316.0], [31.3, 316.0], [31.4, 316.0], [31.5, 316.0], [31.6, 316.0], [31.7, 316.0], [31.8, 316.0], [31.9, 316.0], [32.0, 316.0], [32.1, 316.0], [32.2, 316.0], [32.3, 316.0], [32.4, 316.0], [32.5, 316.0], [32.6, 316.0], [32.7, 316.0], [32.8, 317.0], [32.9, 317.0], [33.0, 317.0], [33.1, 317.0], [33.2, 317.0], [33.3, 317.0], [33.4, 317.0], [33.5, 317.0], [33.6, 317.0], [33.7, 317.0], [33.8, 317.0], [33.9, 317.0], [34.0, 317.0], [34.1, 317.0], [34.2, 317.0], [34.3, 317.0], [34.4, 317.0], [34.5, 321.0], [34.6, 321.0], [34.7, 321.0], [34.8, 321.0], [34.9, 321.0], [35.0, 321.0], [35.1, 321.0], [35.2, 321.0], [35.3, 321.0], [35.4, 321.0], [35.5, 321.0], [35.6, 321.0], [35.7, 321.0], [35.8, 321.0], [35.9, 321.0], [36.0, 321.0], [36.1, 323.0], [36.2, 323.0], [36.3, 323.0], [36.4, 323.0], [36.5, 323.0], [36.6, 323.0], [36.7, 323.0], [36.8, 323.0], [36.9, 323.0], [37.0, 323.0], [37.1, 323.0], [37.2, 323.0], [37.3, 323.0], [37.4, 323.0], [37.5, 323.0], [37.6, 323.0], [37.7, 323.0], [37.8, 324.0], [37.9, 324.0], [38.0, 324.0], [38.1, 324.0], [38.2, 324.0], [38.3, 324.0], [38.4, 324.0], [38.5, 324.0], [38.6, 324.0], [38.7, 324.0], [38.8, 324.0], [38.9, 324.0], [39.0, 324.0], [39.1, 324.0], [39.2, 324.0], [39.3, 324.0], [39.4, 324.0], [39.5, 324.0], [39.6, 324.0], [39.7, 324.0], [39.8, 324.0], [39.9, 324.0], [40.0, 324.0], [40.1, 324.0], [40.2, 324.0], [40.3, 324.0], [40.4, 324.0], [40.5, 324.0], [40.6, 324.0], [40.7, 324.0], [40.8, 324.0], [40.9, 324.0], [41.0, 333.0], [41.1, 333.0], [41.2, 333.0], [41.3, 333.0], [41.4, 333.0], [41.5, 333.0], [41.6, 333.0], [41.7, 333.0], [41.8, 333.0], [41.9, 333.0], [42.0, 333.0], [42.1, 333.0], [42.2, 333.0], [42.3, 333.0], [42.4, 333.0], [42.5, 333.0], [42.6, 333.0], [42.7, 334.0], [42.8, 334.0], [42.9, 334.0], [43.0, 334.0], [43.1, 334.0], [43.2, 334.0], [43.3, 334.0], [43.4, 334.0], [43.5, 334.0], [43.6, 334.0], [43.7, 334.0], [43.8, 334.0], [43.9, 334.0], [44.0, 334.0], [44.1, 334.0], [44.2, 334.0], [44.3, 337.0], [44.4, 337.0], [44.5, 337.0], [44.6, 337.0], [44.7, 337.0], [44.8, 337.0], [44.9, 337.0], [45.0, 337.0], [45.1, 337.0], [45.2, 337.0], [45.3, 337.0], [45.4, 337.0], [45.5, 337.0], [45.6, 337.0], [45.7, 337.0], [45.8, 337.0], [45.9, 337.0], [46.0, 338.0], [46.1, 338.0], [46.2, 338.0], [46.3, 338.0], [46.4, 338.0], [46.5, 338.0], [46.6, 338.0], [46.7, 338.0], [46.8, 338.0], [46.9, 338.0], [47.0, 338.0], [47.1, 338.0], [47.2, 338.0], [47.3, 338.0], [47.4, 338.0], [47.5, 338.0], [47.6, 339.0], [47.7, 339.0], [47.8, 339.0], [47.9, 339.0], [48.0, 339.0], [48.1, 339.0], [48.2, 339.0], [48.3, 339.0], [48.4, 339.0], [48.5, 339.0], [48.6, 339.0], [48.7, 339.0], [48.8, 339.0], [48.9, 339.0], [49.0, 339.0], [49.1, 339.0], [49.2, 340.0], [49.3, 340.0], [49.4, 340.0], [49.5, 340.0], [49.6, 340.0], [49.7, 340.0], [49.8, 340.0], [49.9, 340.0], [50.0, 340.0], [50.1, 340.0], [50.2, 340.0], [50.3, 340.0], [50.4, 340.0], [50.5, 340.0], [50.6, 340.0], [50.7, 340.0], [50.8, 340.0], [50.9, 342.0], [51.0, 342.0], [51.1, 342.0], [51.2, 342.0], [51.3, 342.0], [51.4, 342.0], [51.5, 342.0], [51.6, 342.0], [51.7, 342.0], [51.8, 342.0], [51.9, 342.0], [52.0, 342.0], [52.1, 342.0], [52.2, 342.0], [52.3, 342.0], [52.4, 342.0], [52.5, 345.0], [52.6, 345.0], [52.7, 345.0], [52.8, 345.0], [52.9, 345.0], [53.0, 345.0], [53.1, 345.0], [53.2, 345.0], [53.3, 345.0], [53.4, 345.0], [53.5, 345.0], [53.6, 345.0], [53.7, 345.0], [53.8, 345.0], [53.9, 345.0], [54.0, 345.0], [54.1, 348.0], [54.2, 348.0], [54.3, 348.0], [54.4, 348.0], [54.5, 348.0], [54.6, 348.0], [54.7, 348.0], [54.8, 348.0], [54.9, 348.0], [55.0, 348.0], [55.1, 348.0], [55.2, 348.0], [55.3, 348.0], [55.4, 348.0], [55.5, 348.0], [55.6, 348.0], [55.7, 348.0], [55.8, 348.0], [55.9, 348.0], [56.0, 348.0], [56.1, 348.0], [56.2, 348.0], [56.3, 348.0], [56.4, 348.0], [56.5, 348.0], [56.6, 348.0], [56.7, 348.0], [56.8, 348.0], [56.9, 348.0], [57.0, 348.0], [57.1, 348.0], [57.2, 348.0], [57.3, 348.0], [57.4, 361.0], [57.5, 361.0], [57.6, 361.0], [57.7, 361.0], [57.8, 361.0], [57.9, 361.0], [58.0, 361.0], [58.1, 361.0], [58.2, 361.0], [58.3, 361.0], [58.4, 361.0], [58.5, 361.0], [58.6, 361.0], [58.7, 361.0], [58.8, 361.0], [58.9, 361.0], [59.0, 361.0], [59.1, 361.0], [59.2, 361.0], [59.3, 361.0], [59.4, 361.0], [59.5, 361.0], [59.6, 361.0], [59.7, 361.0], [59.8, 361.0], [59.9, 361.0], [60.0, 361.0], [60.1, 361.0], [60.2, 361.0], [60.3, 361.0], [60.4, 361.0], [60.5, 361.0], [60.6, 361.0], [60.7, 362.0], [60.8, 362.0], [60.9, 362.0], [61.0, 362.0], [61.1, 362.0], [61.2, 362.0], [61.3, 362.0], [61.4, 362.0], [61.5, 362.0], [61.6, 362.0], [61.7, 362.0], [61.8, 362.0], [61.9, 362.0], [62.0, 362.0], [62.1, 362.0], [62.2, 362.0], [62.3, 363.0], [62.4, 363.0], [62.5, 363.0], [62.6, 363.0], [62.7, 363.0], [62.8, 363.0], [62.9, 363.0], [63.0, 363.0], [63.1, 363.0], [63.2, 363.0], [63.3, 363.0], [63.4, 363.0], [63.5, 363.0], [63.6, 363.0], [63.7, 363.0], [63.8, 363.0], [63.9, 363.0], [64.0, 364.0], [64.1, 364.0], [64.2, 364.0], [64.3, 364.0], [64.4, 364.0], [64.5, 364.0], [64.6, 364.0], [64.7, 364.0], [64.8, 364.0], [64.9, 364.0], [65.0, 364.0], [65.1, 364.0], [65.2, 364.0], [65.3, 364.0], [65.4, 364.0], [65.5, 364.0], [65.6, 371.0], [65.7, 371.0], [65.8, 371.0], [65.9, 371.0], [66.0, 371.0], [66.1, 371.0], [66.2, 371.0], [66.3, 371.0], [66.4, 371.0], [66.5, 371.0], [66.6, 371.0], [66.7, 371.0], [66.8, 371.0], [66.9, 371.0], [67.0, 371.0], [67.1, 371.0], [67.2, 371.0], [67.3, 372.0], [67.4, 372.0], [67.5, 372.0], [67.6, 372.0], [67.7, 372.0], [67.8, 372.0], [67.9, 372.0], [68.0, 372.0], [68.1, 372.0], [68.2, 372.0], [68.3, 372.0], [68.4, 372.0], [68.5, 372.0], [68.6, 372.0], [68.7, 372.0], [68.8, 372.0], [68.9, 373.0], [69.0, 373.0], [69.1, 373.0], [69.2, 373.0], [69.3, 373.0], [69.4, 373.0], [69.5, 373.0], [69.6, 373.0], [69.7, 373.0], [69.8, 373.0], [69.9, 373.0], [70.0, 373.0], [70.1, 373.0], [70.2, 373.0], [70.3, 373.0], [70.4, 373.0], [70.5, 375.0], [70.6, 375.0], [70.7, 375.0], [70.8, 375.0], [70.9, 375.0], [71.0, 375.0], [71.1, 375.0], [71.2, 375.0], [71.3, 375.0], [71.4, 375.0], [71.5, 375.0], [71.6, 375.0], [71.7, 375.0], [71.8, 375.0], [71.9, 375.0], [72.0, 375.0], [72.1, 375.0], [72.2, 376.0], [72.3, 376.0], [72.4, 376.0], [72.5, 376.0], [72.6, 376.0], [72.7, 376.0], [72.8, 376.0], [72.9, 376.0], [73.0, 376.0], [73.1, 376.0], [73.2, 376.0], [73.3, 376.0], [73.4, 376.0], [73.5, 376.0], [73.6, 376.0], [73.7, 376.0], [73.8, 385.0], [73.9, 385.0], [74.0, 385.0], [74.1, 385.0], [74.2, 385.0], [74.3, 385.0], [74.4, 385.0], [74.5, 385.0], [74.6, 385.0], [74.7, 385.0], [74.8, 385.0], [74.9, 385.0], [75.0, 385.0], [75.1, 385.0], [75.2, 385.0], [75.3, 385.0], [75.4, 385.0], [75.5, 385.0], [75.6, 385.0], [75.7, 385.0], [75.8, 385.0], [75.9, 385.0], [76.0, 385.0], [76.1, 385.0], [76.2, 385.0], [76.3, 385.0], [76.4, 385.0], [76.5, 385.0], [76.6, 385.0], [76.7, 385.0], [76.8, 385.0], [76.9, 385.0], [77.0, 385.0], [77.1, 386.0], [77.2, 386.0], [77.3, 386.0], [77.4, 386.0], [77.5, 386.0], [77.6, 386.0], [77.7, 386.0], [77.8, 386.0], [77.9, 386.0], [78.0, 386.0], [78.1, 386.0], [78.2, 386.0], [78.3, 386.0], [78.4, 386.0], [78.5, 386.0], [78.6, 386.0], [78.7, 388.0], [78.8, 388.0], [78.9, 388.0], [79.0, 388.0], [79.1, 388.0], [79.2, 388.0], [79.3, 388.0], [79.4, 388.0], [79.5, 388.0], [79.6, 388.0], [79.7, 388.0], [79.8, 388.0], [79.9, 388.0], [80.0, 388.0], [80.1, 388.0], [80.2, 388.0], [80.3, 388.0], [80.4, 395.0], [80.5, 395.0], [80.6, 395.0], [80.7, 395.0], [80.8, 395.0], [80.9, 395.0], [81.0, 395.0], [81.1, 395.0], [81.2, 395.0], [81.3, 395.0], [81.4, 395.0], [81.5, 395.0], [81.6, 395.0], [81.7, 395.0], [81.8, 395.0], [81.9, 395.0], [82.0, 397.0], [82.1, 397.0], [82.2, 397.0], [82.3, 397.0], [82.4, 397.0], [82.5, 397.0], [82.6, 397.0], [82.7, 397.0], [82.8, 397.0], [82.9, 397.0], [83.0, 397.0], [83.1, 397.0], [83.2, 397.0], [83.3, 397.0], [83.4, 397.0], [83.5, 397.0], [83.6, 397.0], [83.7, 398.0], [83.8, 398.0], [83.9, 398.0], [84.0, 398.0], [84.1, 398.0], [84.2, 398.0], [84.3, 398.0], [84.4, 398.0], [84.5, 398.0], [84.6, 398.0], [84.7, 398.0], [84.8, 398.0], [84.9, 398.0], [85.0, 398.0], [85.1, 398.0], [85.2, 398.0], [85.3, 398.0], [85.4, 398.0], [85.5, 398.0], [85.6, 398.0], [85.7, 398.0], [85.8, 398.0], [85.9, 398.0], [86.0, 398.0], [86.1, 398.0], [86.2, 398.0], [86.3, 398.0], [86.4, 398.0], [86.5, 398.0], [86.6, 398.0], [86.7, 398.0], [86.8, 398.0], [86.9, 398.0], [87.0, 398.0], [87.1, 398.0], [87.2, 398.0], [87.3, 398.0], [87.4, 398.0], [87.5, 398.0], [87.6, 398.0], [87.7, 398.0], [87.8, 398.0], [87.9, 398.0], [88.0, 398.0], [88.1, 398.0], [88.2, 398.0], [88.3, 398.0], [88.4, 398.0], [88.5, 398.0], [88.6, 399.0], [88.7, 399.0], [88.8, 399.0], [88.9, 399.0], [89.0, 399.0], [89.1, 399.0], [89.2, 399.0], [89.3, 399.0], [89.4, 399.0], [89.5, 399.0], [89.6, 399.0], [89.7, 399.0], [89.8, 399.0], [89.9, 399.0], [90.0, 399.0], [90.1, 399.0], [90.2, 403.0], [90.3, 403.0], [90.4, 403.0], [90.5, 403.0], [90.6, 403.0], [90.7, 403.0], [90.8, 403.0], [90.9, 403.0], [91.0, 403.0], [91.1, 403.0], [91.2, 403.0], [91.3, 403.0], [91.4, 403.0], [91.5, 403.0], [91.6, 403.0], [91.7, 403.0], [91.8, 403.0], [91.9, 1008.0], [92.0, 1008.0], [92.1, 1008.0], [92.2, 1008.0], [92.3, 1008.0], [92.4, 1008.0], [92.5, 1008.0], [92.6, 1008.0], [92.7, 1008.0], [92.8, 1008.0], [92.9, 1008.0], [93.0, 1008.0], [93.1, 1008.0], [93.2, 1008.0], [93.3, 1008.0], [93.4, 1008.0], [93.5, 1012.0], [93.6, 1012.0], [93.7, 1012.0], [93.8, 1012.0], [93.9, 1012.0], [94.0, 1012.0], [94.1, 1012.0], [94.2, 1012.0], [94.3, 1012.0], [94.4, 1012.0], [94.5, 1012.0], [94.6, 1012.0], [94.7, 1012.0], [94.8, 1012.0], [94.9, 1012.0], [95.0, 1012.0], [95.1, 1120.0], [95.2, 1120.0], [95.3, 1120.0], [95.4, 1120.0], [95.5, 1120.0], [95.6, 1120.0], [95.7, 1120.0], [95.8, 1120.0], [95.9, 1120.0], [96.0, 1120.0], [96.1, 1120.0], [96.2, 1120.0], [96.3, 1120.0], [96.4, 1120.0], [96.5, 1120.0], [96.6, 1120.0], [96.7, 1120.0], [96.8, 1132.0], [96.9, 1132.0], [97.0, 1132.0], [97.1, 1132.0], [97.2, 1132.0], [97.3, 1132.0], [97.4, 1132.0], [97.5, 1132.0], [97.6, 1132.0], [97.7, 1132.0], [97.8, 1132.0], [97.9, 1132.0], [98.0, 1132.0], [98.1, 1132.0], [98.2, 1132.0], [98.3, 1132.0], [98.4, 1149.0], [98.5, 1149.0], [98.6, 1149.0], [98.7, 1149.0], [98.8, 1149.0], [98.9, 1149.0], [99.0, 1149.0], [99.1, 1149.0], [99.2, 1149.0], [99.3, 1149.0], [99.4, 1149.0], [99.5, 1149.0], [99.6, 1149.0], [99.7, 1149.0], [99.8, 1149.0], [99.9, 1149.0], [100.0, 1149.0]], "isOverall": false, "label": "API Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 100.0, "maxY": 43.0, "series": [{"data": [[1100.0, 3.0], [300.0, 43.0], [200.0, 8.0], [100.0, 4.0], [400.0, 1.0], [1000.0, 2.0]], "isOverall": false, "label": "API Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 1100.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 5.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 56.0, "series": [{"data": [[0.0, 56.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 5.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.79221416E12, "maxY": 1.0, "series": [{"data": [[1.79221422E12, 1.0], [1.79221416E12, 1.0]], "isOverall": false, "label": "Virtual Users", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79221422E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 392.90163934426226, "minX": 1.0, "maxY": 392.90163934426226, "series": [{"data": [[1.0, 392.90163934426226]], "isOverall": false, "label": "API Request", "isController": false}, {"data": [[1.0, 392.90163934426226]], "isOverall": false, "label": "API Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 1.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 32.666666666666664, "minX": 1.79221416E12, "maxY": 1036.4833333333333, "series": [{"data": [[1.79221422E12, 308.6333333333333], [1.79221416E12, 1036.4833333333333]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79221422E12, 32.666666666666664], [1.79221416E12, 109.66666666666667]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79221422E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 392.29787234042556, "minX": 1.79221416E12, "maxY": 394.92857142857144, "series": [{"data": [[1.79221422E12, 394.92857142857144], [1.79221416E12, 392.29787234042556]], "isOverall": false, "label": "API Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79221422E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 392.10638297872345, "minX": 1.79221416E12, "maxY": 394.7142857142857, "series": [{"data": [[1.79221422E12, 394.7142857142857], [1.79221416E12, 392.10638297872345]], "isOverall": false, "label": "API Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79221422E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.79221416E12, "maxY": 14.46808510638298, "series": [{"data": [[1.79221422E12, 0.0], [1.79221416E12, 14.46808510638298]], "isOverall": false, "label": "API Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79221422E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 173.0, "minX": 1.79221416E12, "maxY": 1149.0, "series": [{"data": [[1.79221422E12, 1149.0], [1.79221416E12, 1132.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79221422E12, 177.0], [1.79221416E12, 173.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79221422E12, 774.0], [1.79221416E12, 524.0000000000017]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79221422E12, 1149.0], [1.79221416E12, 1132.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79221422E12, 343.5], [1.79221416E12, 340.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.79221422E12, 1149.0], [1.79221416E12, 1076.7999999999993]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79221422E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 337.0, "minX": 1.0, "maxY": 692.5, "series": [{"data": [[2.0, 692.5], [1.0, 337.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 2.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 337.0, "minX": 1.0, "maxY": 690.0, "series": [{"data": [[2.0, 690.0], [1.0, 337.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 2.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.21666666666666667, "minX": 1.79221416E12, "maxY": 0.8, "series": [{"data": [[1.79221422E12, 0.21666666666666667], [1.79221416E12, 0.8]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79221422E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.23333333333333334, "minX": 1.79221416E12, "maxY": 0.7833333333333333, "series": [{"data": [[1.79221422E12, 0.23333333333333334], [1.79221416E12, 0.7833333333333333]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79221422E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.23333333333333334, "minX": 1.79221416E12, "maxY": 0.7833333333333333, "series": [{"data": [[1.79221422E12, 0.23333333333333334], [1.79221416E12, 0.7833333333333333]], "isOverall": false, "label": "API Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79221422E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.23333333333333334, "minX": 1.79221416E12, "maxY": 0.7833333333333333, "series": [{"data": [[1.79221422E12, 0.23333333333333334], [1.79221416E12, 0.7833333333333333]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79221422E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

